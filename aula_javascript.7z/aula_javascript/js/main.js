var nome = "Rafael Galleani";
var idade = 29;
alert(nome + "tem " + idade + " anos");